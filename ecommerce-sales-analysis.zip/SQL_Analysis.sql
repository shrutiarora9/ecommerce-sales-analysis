-- Total revenue by category
SELECT Category, SUM(Price*Quantity) AS Total_Revenue
FROM Sales
GROUP BY Category
ORDER BY Total_Revenue DESC;

-- Monthly revenue
SELECT STRFTIME('%Y-%m', OrderDate) AS Month, SUM(Price*Quantity) AS Revenue
FROM Sales
GROUP BY Month
ORDER BY Month;

-- Top 5 products by revenue
SELECT Product, SUM(Price*Quantity) AS Product_Revenue
FROM Sales
GROUP BY Product
ORDER BY Product_Revenue DESC
LIMIT 5;

-- Average order value
SELECT ROUND(AVG(Price*Quantity),2) AS Avg_Order_Value
FROM Sales;
