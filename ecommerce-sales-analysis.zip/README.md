# 🛒 E-Commerce Sales & Customer Insights

## 📌 Overview
This project analyzes a synthetic e-commerce dataset to explore:
- Revenue patterns across categories and products
- Monthly revenue trends
- Customer purchasing behavior

## 🛠 Tools Used
- Python (Pandas, Matplotlib, Seaborn)
- SQL (queries for KPIs)
- Excel (Pivot tables & charts)
- Dataset: ecommerce_sales.csv

## 📊 Key Insights
- Electronics category generated the highest revenue
- Monthly revenue shows clear growth trends
- Certain low-cost items like T-Shirts and Headphones had strong sales volume

## 📂 Repository Structure
```
ecommerce-sales-analysis/
│
├── ecommerce_sales.csv
├── sales_analysis.ipynb
├── SQL_Analysis.sql
└── README.md
```

## 🚀 How to Run
1. Clone the repo  
2. Open `ecommerce_sales.csv` in Excel for quick view  
3. Run `sales_analysis.ipynb` in Jupyter Notebook  
4. Load `SQL_Analysis.sql` into MySQL/PostgreSQL  
